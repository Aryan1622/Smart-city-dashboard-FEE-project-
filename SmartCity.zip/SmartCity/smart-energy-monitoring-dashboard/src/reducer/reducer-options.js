
export default function () {
    return [
        {
            id: 1,
            name: "Dashboard"
        },
        {
            id: 2,
            name: "Cost"
        },
        {
            id: 3,
            name: "Appliances"
        },
        {
            id: 4,
            name: "Usage-by-rooms"
        },
        {
            id: 5,
            name: "Emissions"
        }
    ]
}